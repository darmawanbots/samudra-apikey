from django.apps import AppConfig


class HeroesConfig(AppConfig):
    name = "heroes"
