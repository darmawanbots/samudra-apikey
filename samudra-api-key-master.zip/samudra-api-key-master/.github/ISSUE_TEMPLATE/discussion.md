---
name: Discussion/Other
about: Discuss something that is not a bug report or a feature request.

---

It's free form! Just start typing.
